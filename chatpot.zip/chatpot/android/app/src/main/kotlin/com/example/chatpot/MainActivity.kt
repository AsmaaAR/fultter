package com.example.chatpot

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
