import 'dart:html';
import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:text_to_speech/text_to_speech.dart';
import 'package:ibm_watson_assistant/ibm_watson_assistant.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
    
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key? key, required this.title}) : super(key: key);
  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  AudioPlayer audio = new AudioPlayer();
  String textAsSpeech = "";
  String apikey = "AYuFtVPMw6HS9MRp1NVZCnYdyeLQrZSCh_1zc2q8E5LQ";
  String ipmurl = "https://api.us-south.text-to-speech.watson.cloud.ibm.com/instances/dfcc76c3-8ba3-4d31-bd00-9b42373eb5aa";
  

  void textToSpeech(String text)async{
   IamOptions options = await IamOptions(iamApikey: apikey, url: ipmurl).build();
   TextToSpeech service = new TextToSpeech(iamOption: options);
   Uint8List voice = await service.toSpeech(text);
   audioPlayer.playBytes(voice);
  }
  

  @override
  Widget build(BuildContext context) {
  
    return Scaffold(
      appBar: AppBar(
      
        title: Text(widget.title),
      ),
      body: Center(
        
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text( onChanged: (value){
                  setState(() {
                    textAsSpeech = value;
                  });
                }),
            ),
            ElevatedButton(onPressed: (){
              textToSpeech(textAsSpeech);
            },
            child: Text("convert")
          ],
            ),
        ),
      );
  }
}

class IamOptions {
  build() {}
}
